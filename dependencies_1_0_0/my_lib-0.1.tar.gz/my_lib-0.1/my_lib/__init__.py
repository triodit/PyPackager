from my_lib.file_1 import average
from my_lib.file_1 import double
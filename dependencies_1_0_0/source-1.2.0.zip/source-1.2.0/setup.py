from distutils.core import setup

setup(
      name         ="source",
      version      ="1.2.0",
      py_modules   =['source'],
      author       ="yang",
      author_email ="1290657017@qq.com",
      url          ="http://www.cctv.com",
      description  =" A simple printer of source list",
      )
